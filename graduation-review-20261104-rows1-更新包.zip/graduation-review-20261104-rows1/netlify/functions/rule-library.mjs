import {timingSafeEqual} from 'node:crypto';
import {getStore} from '@netlify/blobs';
import {makeLibrary,validateLibrary} from '../../dist/rule-schema.mjs';
import seedPlans from '../../dist/rules.json' with {type:'json'};

const headers={'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};
const json=(body,status=200,extra={})=>new Response(JSON.stringify(body),{status,headers:{...headers,...extra}});
function authorized(req,token){
  token=String(token||'').trim();if(token.length<16)return false;
  const received=req.headers.get('authorization')||'',expected=`Bearer ${token}`;
  const a=Buffer.from(received),b=Buffer.from(expected);return a.length===b.length&&timingSafeEqual(a,b);
}
export function makeHandler({store,adminToken,seed=makeLibrary(seedPlans)}){
  return async req=>{
    const wantsAdmin=new URL(req.url).searchParams.get('admin')==='1';
    if(req.method!=='GET'&&req.method!=='PUT')return json({error:'不支持此操作'},405,{Allow:'GET, PUT'});
    if(wantsAdmin||req.method==='PUT'){
      if(!adminToken||adminToken.trim().length<16)return json({error:'管理员口令未配置：请在Netlify环境变量中设置至少16位的RULES_ADMIN_TOKEN'},503);
      if(!authorized(req,adminToken))return json({error:'管理员口令错误或权限已失效'},401);
    }
    try{
      const entry=await store.getWithMetadata('library',{type:'json',consistency:'strong'});
      const current=entry?.data||seed,etag=entry?.etag||'none';
      if(req.method==='GET')return json({...current,save_protocol:2},200,{ETag:etag});
      // 以规则库修订号检查浏览器版本，存储层再用ETag原子写入。
      // 不把HTTP缓存ETag当作用户保存前置条件，避免代理/压缩改写头部导致永久冲突。
      const raw=await req.text();if(Buffer.byteLength(raw)>4_000_000)return json({error:'规则库超过4MB，请减少重复原文或拆分资料'},413);
      let library;try{library=JSON.parse(raw);validateLibrary(library);}catch(error){return json({error:error.message||'规则格式不正确'},400);}
      // 兼容尚未刷新网页的旧客户端：未提供新设置时保留网站当前值。
      if(library.default_audit_mode===undefined)library.default_audit_mode=current.default_audit_mode??'current';
      if(library.revision!==(current.revision||0))return json({error:'规则已有更新，正在自动合并后重试。'},409);
      library={...library,revision:(current.revision||0)+1,updated_at:new Date().toISOString()};
      const saved=await store.setJSON('library',library,entry?{onlyIfMatch:etag}:{onlyIfNew:true});
      if(!saved.modified)return json({error:'保存时有其他更新，正在自动重试，草稿已保留。'},409);
      return json({library},200,{ETag:saved.etag});
    }catch(error){return json({error:'规则共享存储暂时不可用，请稍后重试；未确认保存成功前请保留草稿'},503);}
  };
}
export default async req=>{try{return await makeHandler({store:getStore({name:'graduation-rule-library',consistency:'strong'}),adminToken:process.env.RULES_ADMIN_TOKEN})(req);}catch{return json({error:'共享规则服务未连接，请检查Netlify部署与Blobs配置'},503);}};
export const config={path:'/api/rule-library'};
